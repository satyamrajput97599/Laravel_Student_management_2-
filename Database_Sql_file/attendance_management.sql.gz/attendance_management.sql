-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 13, 2024 at 06:47 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `attendance_management`
--

-- --------------------------------------------------------

--
-- Table structure for table `checkattendance`
--

CREATE TABLE `checkattendance` (
  `id` int(50) NOT NULL,
  `sid` int(50) NOT NULL,
  `dt` varchar(50) NOT NULL,
  `st` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `class`
--

CREATE TABLE `class` (
  `id` int(11) NOT NULL,
  `course` varchar(100) NOT NULL,
  `level` varchar(50) NOT NULL,
  `section` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `class`
--

INSERT INTO `class` (`id`, `course`, `level`, `section`) VALUES
(1, 'Course 2', '2-1', 'A'),
(2, 'Course 1', '2-1', 'A'),
(5, 'Course 4', '2-5', 'D'),
(6, 'Course 1', '2-5', 'D'),
(7, 'Course 1', '2-5', 'D'),
(8, 'Course 1', '2-5', 'D');

-- --------------------------------------------------------

--
-- Table structure for table `classsubject`
--

CREATE TABLE `classsubject` (
  `id` int(11) NOT NULL,
  `class` varchar(100) NOT NULL,
  `subject` varchar(100) NOT NULL,
  `faculty` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `classsubject`
--

INSERT INTO `classsubject` (`id`, `class`, `subject`, `faculty`) VALUES
(4, 'Course 5-2 B', 'Subject 1', 'Rohit'),
(5, 'Course 5-2 B', 'Subject 1', 'Rohit'),
(6, 'Course 5-4 D', 'Subject 2', 'Shivam'),
(7, 'Course 5-1 A', 'Subject 3', 'Rohit'),
(8, 'Course 5-1 A', 'Subject 1', 'Shivam'),
(9, 'Course 5-3 C', 'Subject 3', 'Rohit');

-- --------------------------------------------------------

--
-- Table structure for table `course`
--

CREATE TABLE `course` (
  `id` int(11) NOT NULL,
  `course` varchar(50) NOT NULL,
  `description` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `course`
--

INSERT INTO `course` (`id`, `course`, `description`) VALUES
(68, 'B-technjvjsjkv', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `faculty`
--

CREATE TABLE `faculty` (
  `#` bigint(20) UNSIGNED NOT NULL,
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `contact` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `address` varchar(100) NOT NULL,
  `subject` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `faculty`
--

INSERT INTO `faculty` (`#`, `id`, `name`, `email`, `contact`, `password`, `address`, `subject`) VALUES
(1, 123, 'Satyam Chauhan', 'satyamrajput643@gmail.com', '25656', '3079', 'Raipur malook\r\nDhakka charamchand', ''),
(6, 1235, 'shivam', 'satyam@gmail.com', '9895454445', '6002', 'Raipur malook\r\nDhakka charamchand', ''),
(2, 12343, 'shivam kumar', 'satyam@gmail.com', '98954544', '6260', 'dehradun', ''),
(8, 12356, 'shivam', 'satyam@gmail.com', '9895454445', '4890', 'Raipur malook\r\nDhakka charamchand', 'Math2.0');

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `id` int(50) NOT NULL,
  `name` varchar(50) NOT NULL,
  `course` varchar(50) NOT NULL,
  `subject` varchar(50) NOT NULL,
  `pid` int(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`id`, `name`, `course`, `subject`, `pid`) VALUES
(66666, 'anjali', 'java 2-B', 'subject2', 2),
(8888, 'aman', 'react 3-c', 'subject2', 3),
(99099, 'amrita', 'python 1-A', 'subject3', 4),
(900099, 'khusbu', 'java 2-B', 'subject2', 7),
(76699, 'tanu', 'react 3-c', 'subject1', 8),
(7644, 'vaishali', 'react 3-c', 'subject3', 9),
(3344, 'pratiksha', 'java 2-B', 'subject1', 10),
(3322, 'sharmila', 'python 1-A', 'subject2', 11),
(2211, 'kajal', 'react 3-c', 'subject4', 12),
(9900, 'lucky', 'java 2-B', 'subject1', 13),
(77666, 'kusum', 'java 2-B', 'subject2', 14),
(77, 'vishal', 'java 2-B', 'subject2', 15),
(9966, 'deepali', 'java 2-B', 'subject2', 16),
(9966, 'deepali', 'java 2-B', 'subject2', 17),
(5454, 'divya', 'java 2-B', 'subject2', 18),
(8898, 'shivam', 'java 2-B', 'subject2', 19),
(5566, 'shivani', 'python 1-A', 'subject1', 20),
(3343, 'kalash', 'java 2-B', 'subject3', 21),
(9009, 'abhishek', 'java 2-B', 'subject2', 22),
(5576, 'abhilash', 'java 2-B', 'subject2', 23),
(7876, 'sachin', 'react 3-c', 'subject2', 24),
(3533, 'anchal', 'react 3-c', 'subject2', 25),
(2435, 'shad', 'java 2-B', 'subject2', 26),
(2422, 'rohan', 'react 3-c', 'subject2', 27),
(8666, 'ronika', 'java 2-B', 'subject1', 28),
(5252, 'avantika', 'java 2-B', 'subject2', 29),
(7656, 'anuradha', 'java 2-B', 'subject1', 30),
(2722, 'anand', 'react 3-c', 'subject2', 31),
(2322, 'golu', 'python 1-A', 'subject2', 32),
(1242, 'sakshi', 'python 1-A', 'subject3', 33),
(2626, 'santoshi', 'python 1-A', 'subject2', 34),
(7676, 'soni', 'python 1-A', 'subject4', 35),
(2622, 'poonam', 'java 2-B', 'subject2', 36),
(9078, 'vaidu', 'react 3-c', 'subject2', 37),
(989, 'rajni', 'java 2-B', 'subject1', 38),
(2321, 'gaurav', 'java 2-B', 'subject1', 39),
(928, 'shagun', 'react 3-c', 'subject3', 40),
(2718, 'tushar', 'java 2-B', 'subject4', 41),
(8722, 'suraj', 'java 2-B', 'subject2', 42),
(928, 'meenakshi', 'java 2-B', 'subject2', 43),
(9836, 'neelam', 'python 1-A', 'subject4', 44),
(2898, 'akku', 'react 3-c', 'subject2', 45),
(9822, 'abha', 'java 2-B', 'subject4', 46),
(192, 'guru', 'java 2-B', 'subject2', 47),
(9882, 'mayank', 'python 1-A', 'subject4', 48),
(393, 'naman', 'java 2-B', 'subject2', 49),
(2827, 'rohit', 'java 2-B', 'subject2', 50),
(2210, 'cheta', 'java 2-B', 'subject2', 51);

-- --------------------------------------------------------

--
-- Table structure for table `subject`
--

CREATE TABLE `subject` (
  `id` int(11) NOT NULL,
  `subject` varchar(50) NOT NULL,
  `description` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `subject`
--

INSERT INTO `subject` (`id`, `subject`, `description`) VALUES
(13, 'Math2', NULL),
(14, 'Math2', NULL),
(15, 'Math2', NULL),
(16, 'Math20', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `uinfo`
--

CREATE TABLE `uinfo` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `checkattendance`
--
ALTER TABLE `checkattendance`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `class`
--
ALTER TABLE `class`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `classsubject`
--
ALTER TABLE `classsubject`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `course`
--
ALTER TABLE `course`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `faculty`
--
ALTER TABLE `faculty`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `#` (`#`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`pid`);

--
-- Indexes for table `subject`
--
ALTER TABLE `subject`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `uinfo`
--
ALTER TABLE `uinfo`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `checkattendance`
--
ALTER TABLE `checkattendance`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `class`
--
ALTER TABLE `class`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `classsubject`
--
ALTER TABLE `classsubject`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `course`
--
ALTER TABLE `course`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=72;

--
-- AUTO_INCREMENT for table `faculty`
--
ALTER TABLE `faculty`
  MODIFY `#` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `student`
--
ALTER TABLE `student`
  MODIFY `pid` int(200) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=52;

--
-- AUTO_INCREMENT for table `subject`
--
ALTER TABLE `subject`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `uinfo`
--
ALTER TABLE `uinfo`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
